# Test papers

Output a **print-ready paper plus a separate answer key** (DOCX + PDF), built with `scripts/make_paper.py`. Accuracy matters more than speed: one wrong answer in a key costs Kishan's credibility in front of students.

## 1. Pin down the brief
Fill these from the request. Ask only for what's missing and can't be inferred.

| Field | Default if not given |
|---|---|
| Class, board | **Ask.** Board decides the pattern. "Both" means CBSE style, header "CBSE / GSEB" |
| Subject, chapters/topics | **Ask** if not given. Use Kishan's chapter names exactly |
| Total marks | 25 |
| Time | 25 marks → 50 min · 40 → 1 h 30 min · 80 → 3 h |
| Difficulty | about 30% easy · 50% medium · 20% challenging |
| Date | blank line on the paper |

**Syllabus caution:** NCERT has new books for Class 8 (*Curiosity*) and Class 9 (*Exploration*, 2026-27). Don't rely on old chapter numbers. Use the topic names Kishan gives, or the chapter list in `reference/academy.md`. If you're unsure whether a topic is still in this year's book, say so in your reply.

## 2. Blueprint (pick by board and size)
These follow the latest **reported** board patterns. Confirm each year against the official sample paper (CBSE: cbseacademic.nic.in · GSEB: gseb.org). If Kishan pastes the official blueprint into `reference/academy.md`, that wins.

**CBSE style (Class 9–10 Science)**: section types are A = MCQ + Assertion–Reason (1), B = very short answer (2), C = short answer (3), D = long answer (5), E = case-based with subparts (4).
| Total | A | B | C | D | E |
|---|---|---|---|---|---|
| 25 | 6×1 | 2×2 | 2×3 | 1×5 | 1×4 |
| 40 | 9×1 | 3×2 | 4×3 | 1×5 | 2×4 |
| 80 (full board pattern) | 20×1 | 6×2 | 7×3 | 3×5 | 3×4 |
Give internal choice (`"or"`) in about one question per section from B onwards. At 80 marks, split roughly Biology 30 · Chemistry 25 · Physics 25 if the paper is full-syllabus.

**GSEB style (Std 9–10 Science)**: A = objective (MCQ, fill in the blank, true/false, one-word, match: 1 each), B = short answer (2), C = short answer + diagrams (3), D = long answer + diagrams (4).
| Total | A | B | C | D |
|---|---|---|---|---|
| 25 | 9×1 | 3×2 | 2×3 | 1×4 |
| 40 | 12×1 | 4×2 | 4×3 | 2×4 |
| 80 (full board pattern) | 24×1 | 9×2 | 6×3 | 5×4 |

**Class 8 / school tests**: a mix of MCQ, fill in the blank, true/false, match the following, short answer, one diagram and one long answer. Keep the language simple.

## 3. Write the questions
- **Every question has exactly one correct answer.** For MCQs, use 4 plausible options with one clearly right; no "all of the above" tricks. Rotate where the correct option sits.
- **Check science atom by atom and unit by unit.** Balance every equation (count each element on both sides). Solve every numerical fully, with units and sensible numbers.
- Mix textbook-style questions with **fresh variants** (changed numbers, new contexts, Indian everyday examples). Don't just copy exercise questions.
- CBSE style needs competency questions: case-based passages, assertion–reason (use the standard 4 options, see the sample), "give reason" and application questions.
- Diagram questions: "Draw a neat, labelled diagram of …" and add `"box_cm": 6` for drawing space if answers are written on the paper. The renderer can't draw figures. For "label this figure" questions, describe the figure in words, or ask Kishan for an image and say it's not embedded.
- Never use real student names. Fictional first names in case studies are fine.
- Write the **answer and marking points** for every question as you go (`answer`, `marking`).

## 4. Build the files
1. Write the spec to `/tmp/papers/<class>-<subject>-<topic>.json`. /tmp is git-ignored.
2. Run `python3 scripts/make_paper.py /tmp/papers/<file>.json --out /mnt/user-data/outputs`.
   The script **refuses to build if the marks don't add up** (section totals, subparts and OR choices). Fix the spec and re-run.
3. **Self-check pass.** Re-read the key as a strict examiner: re-solve every numerical, re-balance every equation, confirm each MCQ has exactly one defensible answer, and check that the time allotted is realistic. Fix and rebuild if anything is off.
4. Send by saving it to /mnt/user-data/outputs: the **paper PDF** and the **answer key PDF**, plus the paper DOCX only if Kishan may edit it.

## 5. Reply (short)
- One line: `Class 10 CBSE · Chemical Reactions · 25 marks / 50 min · 6 MCQ, 2×2, 2×3, 1×5, 1 case study`.
- Anything Kishan should check (a topic that may have moved in the new book, a figure not included).
- Offer one next step: "Want a **Set B** (same pattern, different questions) or a matching practice worksheet?"

## Spec format (JSON)
See `samples/class10-science-ch1-unit-test.json` for a complete example.
```json
{
  "type": "test",
  "title": "Unit Test: <topic>", "class": "10", "board": "CBSE", "subject": "Science",
  "chapter": "<chapter names>", "time": "50 minutes", "total_marks": 25, "date": "",
  "instructions": ["All questions are compulsory.", "..."],
  "sections": [
    {"title": "Section A", "note": "Choose the correct option.", "questions": [
      {"q": "Question with H_{2}O and 10^{-3} markup", "marks": 1,
       "options": ["...", "...", "...", "..."], "answer": "(b) ..."}
    ]},
    {"title": "Section C", "questions": [
      {"q": "Stem / case text", "subparts": [
        {"q": "Part (i)", "marks": 1, "answer": "..."},
        {"q": "Part (ii)", "marks": 2, "answer": "...", "marking": ["point: 1", "point: 1"]}
      ]},
      {"q": "Main question", "marks": 3, "answer": "...",
       "or": {"q": "Alternative question", "marks": 3, "answer": "..."}}
    ]}
  ],
  "closing": "All the best!"
}
```
Inline markup: `**bold**`, `H_{2}O` (subscript) and `Fe^{3+}` (superscript). Optional per question: `"box_cm": 6` (drawing box) and `"lines": 4` (answer lines, worksheets only). Optional top-level: `"file_name"` and `"academy"`.
