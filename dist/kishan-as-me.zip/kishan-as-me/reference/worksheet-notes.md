# Worksheets & notes

**Check `library/INDEX.md` first.** Class 10 Science already has a one-page revision sheet for all 13 chapters, plus a 90-day plan with an error-log page. Send those directly, or adapt their specs.

Same engine and the same accuracy bar as `reference/test-paper.md`. Read its sections **1 (brief)** and **3 (write the questions)**. The differences are below.

## Pick the format
| Request | `type` | Shape |
|---|---|---|
| Practice / homework / revision worksheet | `worksheet` | Questions with answer lines (`"lines": n`), no marks needed, plus a separate answer key |
| Chapter question bank / important questions | `worksheet` | Grouped by type (1-mark, 2-mark, 3-mark, 5-mark), `"lines": 0`, plus answer key |
| Daily practice (DPP) / notebook homework | `worksheet` + `"answer_lines": false` | Question-only sheet (answers go in the notebook), sections "Day 1/2/3", plus answer key. Class 10 already has one per chapter in `library/class10-science/dpp/` |
| Short notes / one-page revision / formula sheet | `notes` | `blocks`: headings, paragraphs, bullets, tables, boxed "Remember" tips |

## Worksheets
- Build in order: warm-up (recall), then core practice, then 1–2 challenge questions.
- Default length: 10–15 questions, which fit on 1–2 pages.
- Answer lines scale with the answer: one-word 1 line, short answer 2–3 lines, explanation 4–6 lines, numerical 4 lines.
- Add a one-line tip in `instructions` in Kishan's voice ("Count every atom on both sides!").
- `closing` gets a warm line ("Keep practising, you've got this!").
- Example spec: `samples/class10-balancing-worksheet.json`.

## Notes
- One page where possible, two at most. Students should be able to revise from it the night before.
- Structure: key terms (table: term | meaning) → core ideas (bullets) → equations/formulas (box) → common mistakes (bullets) → 3 quick self-check questions (lines).
- Only the most-tested points. Use short phrases, not paragraphs.

Notes spec:
```json
{
  "type": "notes", "title": "Quick Revision: <topic>", "class": "9", "board": "CBSE", "subject": "Science",
  "blocks": [
    {"h": "Key terms"},
    {"table": [["Term", "Meaning"], ["Speed", "Distance travelled per unit time"]]},
    {"h": "Must-know points"},
    {"bullets": ["...", "..."]},
    {"box": ["Remember: v = u + at", "s = ut + ½at^{2}"]},
    {"h": "Quick check"},
    {"p": "1. ..."}, {"lines": 2}
  ]
}
```
Other blocks: `{"image": "fig.png", "width_cm": 8, "caption": "..."}`, `{"pagebreak": true}`. Tables size their columns to the text automatically. Override with `"col_widths": [2, 4, 11.6]` (cm), and add `"row_height_cm": 1` for write-in tables such as an error log. Mark a block `"unbalanced": true` if it deliberately shows a wrong equation.

## Build & deliver
1. Write the spec to `/tmp/papers/<name>.json`.
2. Run `python3 scripts/make_paper.py /tmp/papers/<name>.json --out /mnt/user-data/outputs`.
3. Self-check: re-solve every answer, re-balance every equation, and check units.
4. Send the PDF(s) by saving it to /mnt/user-data/outputs: the worksheet and the answer key. Add the DOCX only if Kishan will edit it.
5. Reply in one line, then offer the natural next thing ("Want the matching 25-mark test?").
